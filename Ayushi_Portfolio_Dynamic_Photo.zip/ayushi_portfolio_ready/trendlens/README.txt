TREN​​DLENS — PORTFOLIO DEMO

Open standalone.html directly in a modern browser. No installation, server, API key or account is required.

The demo includes market scoping, client-side review sentiment/theme analysis, CSV import, competitor CRUD, heuristic opportunity scoring, a connected product strategy, editable PRD export/print, and a GTM scenario calculator. Workspace edits persist in localStorage in the browser where the file is opened. Data does not sync across devices.

All included market data and projections are illustrative demonstration content, not live research, real AI output or business forecasts.
