# GrowthOS

GrowthOS is a standalone, responsive business growth workspace built with React, Vite, Recharts and Lucide icons. It includes an interactive overview, CRM, customer directory, analytics, product roadmap, project tracker and email campaign planning studio.

> **Prototype/data note:** The initial records and metrics are fictional demonstration data. GrowthOS is a client-side prototype: records are saved in the current browser's `localStorage`. It does not include authentication, a hosted database, email delivery or multi-user sync.

## Run locally

Requirements: Node.js 18+ and npm.

```bash
# 1. Extract the project ZIP and enter the folder
cd growthos

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev
```

Vite prints a local URL (usually `http://localhost:5173`). Open it in your browser.

## Production build

```bash
npm run build
npm run preview
```

The production-ready static site is generated in `dist/`.

## Deploy free on Vercel

1. Create a Git repository and push this `growthos` folder to GitHub.
2. Sign in to [Vercel](https://vercel.com/) and choose **Add New → Project**.
3. Import the GitHub repository.
4. Use these settings (Vercel normally detects Vite automatically):
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Output directory: `dist`
   - Install command: `npm install`
5. Click **Deploy**. Vercel will provide a hosted URL such as `https://your-growthos.vercel.app`.
6. Future updates can be deployed by pushing commits to the connected branch.

No environment variables are required for this frontend-only prototype.

## Connect GrowthOS to a separate portfolio website later

Keep the two projects independent. Deploy GrowthOS as its own Vercel project and leave the portfolio's existing hosting and files unchanged. Then add a link in the portfolio navigation or project card:

```html
<a href="https://your-growthos.vercel.app" target="_blank" rel="noopener noreferrer">
  Open GrowthOS ↗
</a>
```

Replace the example URL with the actual deployed GrowthOS URL. The portfolio archive provided for this build is a static HTML/CSS/JS site; a simple external link is the cleanest initial integration. You can optionally use a custom subdomain such as `growth.yourdomain.com` by adding it in Vercel's project **Settings → Domains** and following its DNS instructions.

If you later want the portfolio and GrowthOS to share real customer/business data, add a secure backend API and database. Do not expose database credentials in frontend code. For production use, add authentication, authorization, server-side validation, backups and audit logging. Email sending should be connected through a provider from a server-side function; the current campaign studio only drafts, previews and tracks planning status.

## Data and persistence

- All CRUD modules update the React application state and save it to `localStorage` under `growthos-data`.
- Won leads automatically appear in Customers; changing a won lead back to another stage removes it from that derived customer list.
- Dashboard totals and CRM-derived analytics update as records change.
- Use **Settings → Export JSON backup** to download a data backup.
- Use **Settings → Reset demo data** to restore the original fictional sample dataset.
- Browser storage is device/browser-specific. Clearing site data removes local records. Export backups before clearing browser data.

## Project structure

```text
growthos/
├── index.html
├── package.json
├── README.md
└── src/
    ├── main.jsx       # App shell, pages, CRUD forms, sample data and charts
    └── style.css      # Responsive premium SaaS interface
```

## Current scope / production considerations

- No fake login or authentication screen is included.
- Email campaign status is a planning label only; no message is transmitted.
- The revenue and lead trend chart includes illustrative historical context. Current CRM counts, pipeline values, conversion and stage/source breakdowns are derived from editable CRM records.
- Local storage is appropriate for a personal demo, not a multi-user production CRM. A backend is needed for cross-device sync and secure collaboration.
