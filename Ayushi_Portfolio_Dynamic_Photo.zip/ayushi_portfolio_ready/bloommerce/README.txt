BLOOMMERCE — Commerce Growth Studio

Open index.html in a browser, or run the main portfolio with the included Vite setup and open /bloommerce/.

This is an interactive portfolio concept using illustrative sample data. It includes:
- Sample storefront with add-to-basket interactions (no checkout or payments)
- Customer journey map
- Social, email and paid campaign briefs
- Growth simulator using visitors × conversion rate × average order value
- Responsive pastel pink and white interface with motion and reduced-motion support

All metrics and outcomes are illustrative demo data, not live store analytics or forecasts.
