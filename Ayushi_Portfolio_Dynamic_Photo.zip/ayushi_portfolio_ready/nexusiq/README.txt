NexusIQ — Business Intelligence & Decision Strategy Platform
A Project by Ayushi | Project 03

OPEN LOCALLY
1. Extract the portfolio ZIP.
2. Open ayushi_portfolio_ready/nexusiq/index.html in a modern browser.
3. From the portfolio homepage, select NexusIQ under the project collection.

No installation, backend, login, paid API or external JavaScript library is required.
The application uses localStorage in the browser for saved requirements, features, feedback,
opportunities, decisions and reports. Data is stored per browser/device and does not sync.

PORTFOLIO INTEGRATION
The portfolio homepage includes a Project 03 NexusIQ card linking to nexusiq/index.html.
The existing GrowthOS, TrendLens and other project files are retained.

DEMO TRANSPARENCY
All metrics and datasets are illustrative. Customer sentiment is rule-based keyword grouping.
Decision outcomes are calculated from transparent editable assumptions and are not forecasts.
CSV import expects columns such as feedback, segment and rating.
